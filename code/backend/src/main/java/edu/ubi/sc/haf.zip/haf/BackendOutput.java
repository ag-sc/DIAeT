package edu.ubi.sc.haf;
import java.util.List;
import java.util.Map;

public class BackendOutput {
	public Map<String, Object> verbalization;
	
	public List<ClinicalTrial> evidence;
}
