package edu.ubi.sc.haf;

public class ClinicalTrial {
	public String id;
	
	public String link;
	
	public String title;
	
	public String authors;
	
	public boolean include;
	
	public String exclusionReason;
	
	public double year;
	
	public double duration;
	
	public double numParticipants;
	
	public double avgAge;
}
