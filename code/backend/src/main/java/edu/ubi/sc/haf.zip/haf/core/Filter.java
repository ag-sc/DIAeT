package edu.ubi.sc.haf.core;

public interface Filter {
	public String getPropertyName();
}
